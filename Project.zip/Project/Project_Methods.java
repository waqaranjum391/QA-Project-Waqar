package Project;

import static org.junit.Assert.assertTrue;
import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class Project_Methods {
	
	WebDriver driver;
	
	Logger log=Logger.getLogger(Project_Objects.class);
		
		@FindBy(id="vchLogin_Name")
		WebElement userNameBox;
		
		@FindBy(id="vchPassword")
		WebElement userPasswordBox;
		
		@FindBy(xpath="//*[@type='button']")
		WebElement loginBtn;
		
		@FindBy(id="fra_Menu_CureMD")
		WebElement sideFrame;

		@FindBy(id="patientBtn")
		WebElement patientBtn;

		@FindBy(xpath="//*[@id='fraCureMD_Body']")
		WebElement mainFrame;

		@FindBy(xpath="//td[@title='Add Patient']")
		WebElement addPatientBtn;

		@FindBy(xpath="//*[@id='txtVFNAME']")
		WebElement firstNameBox;

		@FindBy(xpath="//*[@id='txtVLNAME']")
		WebElement lastNameBox;

		@FindBy(xpath="//select[@id='cmbVTitle']")
		WebElement nameTitleDD;

		@FindBy(xpath="//*[@id='cmbVSEX']")
		WebElement genderDD;

		@FindBy(id="txtDDOB")
		WebElement patientDOBBox;

		@FindBy(xpath="//span[@id='select2-cmbILOCID-container']")
		WebElement patientLocation1;
		
		@FindBy(xpath="//input[@class='select2-search__field']")
		WebElement patientLocation2;

		@FindBy(id="txtvcity")
		WebElement patientCityBox;

		@FindBy(id="txtVSTATE")
		WebElement patientStateBox;

		@FindBy(id="txtVZIP")
		WebElement patientZIPBox1;
		
		@FindBy(id="txtVZIPCODEEXT")
		WebElement patientZIPBox2;
		
		@FindBy(id="txtVEMAIL")
		WebElement patientEmailBox;

		@FindBy(id="imgpInsurance")
		WebElement primaryInsuranceExpandBtn;
		
		@FindBy(id="cmbIPLANID")
		WebElement primaryInsurancePlanDD;

		@FindBy(id="txtDSIGNONFILE")
		WebElement primarySignOnFileBox;

		@FindBy(id="cmbPlanAdd")
		WebElement primaryInsuranceAddressDD;
		
		@FindBy(id="imgSInsurance")
		WebElement secondaryInsuranceExpandBtn;

		@FindBy(id="cmbSECPLANID")
		WebElement secondaryInsurancePlanDD;

		@FindBy(id="cmbSecPlanAdd")
		WebElement secondaryInsuranceAddressDD;
		
		@FindBy(id="txtSecDSIGNONFILE")
		WebElement secondarySignOnFileBox;

		@FindBy(id="tdsave")
		WebElement saveBtn;
		
		@FindBy(id="DynamicBHdialogbox")
		WebElement duplicatePatientsFrame;
		
		@FindBy(id="saveAsNewButton")
		WebElement saveAsNewBtn;
		
		@FindBy(id="vchPat_Name")
		WebElement patientFullName;
		
		@FindBy(xpath="//*[@id='fraCureMD_Patient_Menu']")
		WebElement patientMenuFrame;
		
		@FindBy(xpath="//a[@id='Provider_Notes_anchor']")
		WebElement providerNotesBtn;
		
		@FindBy(xpath="//a[@id='Provider_Notes_New_Case_anchor']")
		WebElement newCaseBtn;
		
		@FindBy(xpath="//input[@id='txtVCNAME']")
		WebElement caseNameBox;
		
		@FindBy(xpath="//input[@id='txtDSTART']")
		WebElement caseOpenDateBox;
		
		@FindBy(xpath="//*[@id='cmdSubmit']")
		WebElement caseSaveBtn;
		
		@FindBy(xpath="//img[@class='btnRowIcon']")
		WebElement deleteCaseBtn;
		
		@FindBy(xpath="//a[@id='Provider_Notes_Provider_Notes_anchor']")
		WebElement providerNotesBtn2;
		
		@FindBy(xpath="//td[@id='SpAdd1']")
		WebElement addProviderNoteBtn;
		
		@FindBy(xpath="//input[@id='Sdate']")
		WebElement providerNotesDateBox;
		
		@FindBy(xpath="//span[@id='select2-cmbProvider-container']")
		WebElement providerBox;
		
		@FindBy(xpath="//select[@id='cmbRTemplate']")
		WebElement noteTemplateDD;
		
		@FindBy(xpath="//select[@id='txtVREASON']")
		WebElement visitReasonDD;
		
		@FindBy(id="cmbReportType")
		WebElement noteTypeDD;
		
		@FindBy(xpath="//td[@id='btnSave']")
		WebElement createBtn;
		
//		@FindBy(xpath="")
//		WebElement ;

		Project_Methods(WebDriver drvr){
			driver=drvr;
			PageFactory.initElements(drvr,this);
		}
		
		public void LoginToThePortal() throws InterruptedException {
			
			WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(30));
			
			wait.until(ExpectedConditions.visibilityOf(userNameBox));
			userNameBox.sendKeys("ChargeModifiers");
			log.info("Enter username");
			
			userPasswordBox.sendKeys("SuPPort.2014");
			log.info("Enter Password");
			
			loginBtn.click();
			log.info("Click on login button");
			Thread.sleep(3000);
			
			String PopupWindow = null;
			Set<String> handles= driver.getWindowHandles();
			log.info("Get Titles of all opened windows");
			
			Iterator<String> iterator = handles.iterator();
			
			while (iterator.hasNext()) {
				PopupWindow = iterator.next();
			}
			
			Thread.sleep(2000);
			driver.switchTo().window(PopupWindow);
			log.info("Switch to pop-up window");
			
			String actualTitle = driver.getTitle();
			Assert.assertEquals(actualTitle, "Personal: Dashboard");
			log.info("Verify that the user has been logged in");
			
		}
		
		public void AddPatient() throws InterruptedException {
			
			WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(30));
			
			driver.switchTo().frame(sideFrame);
			log.info("Switch to the left frame");
			Thread.sleep(2000);
			
			wait.until(ExpectedConditions.visibilityOf(patientBtn));
			patientBtn.click();
			log.info("Click on the patient button");
			Thread.sleep(1000);
			
			driver.switchTo().defaultContent();
			log.info("Switch to default frame");
			Thread.sleep(2000);
			
			driver.switchTo().frame(mainFrame);
			log.info("Switch to main (body) frmae");
			Thread.sleep(2000);
			
			addPatientBtn.click();
			log.info("Click on the add patient button");
			Thread.sleep(1000);
			
			String firstName = RandomStringUtils.randomAlphabetic(6);
			log.info("Enter first name of the patient");
			firstNameBox.sendKeys(firstName);
			
			String lastName = RandomStringUtils.randomAlphabetic(6);
			log.info("Enter last name of the patient");
			lastNameBox.sendKeys(lastName);
			
			Select patientTitle = new Select(nameTitleDD);
			patientTitle.selectByIndex(0);
			log.info("Select title of the patient");
			
			Select patientGender = new Select(genderDD);
			patientGender.selectByVisibleText("Male");
			log.info("Select gender of the patient");
			
			patientDOBBox.sendKeys("09/07/1999");
			log.info("Enter DOB of the patient");
			
			patientLocation1.click();
			patientLocation2.sendKeys("abc"+Keys.ENTER);
			log.info("Enter Location of the patient");
			
			String Email = RandomStringUtils.randomAlphabetic(8);
			patientEmailBox.sendKeys(Email+"@xyz.com");
			log.info("Enter Email of the patient");
			
			String city = RandomStringUtils.randomAlphabetic(7);
			patientCityBox.sendKeys(city);
			log.info("Enter City of the patient");
			
			String state = RandomStringUtils.randomAlphabetic(4);
			patientStateBox.sendKeys(state);
			log.info("Enter state of the patient");
			
			patientZIPBox1.sendKeys("11111");
			patientZIPBox2.sendKeys("22222");
			log.info("Enter ZIP Code of the patient");
			
			primaryInsuranceExpandBtn.click();
			log.info("Expand the primary Insurance block");
			
			Select PriPlan = new Select(primaryInsurancePlanDD);
			PriPlan.selectByIndex(1);
			log.info("Select the primary Insurance Plan");
			
			Select PriAdd = new Select(primaryInsuranceAddressDD);
			PriAdd.selectByIndex(1);
			log.info("Select the primary Insurance Address");
			
			primarySignOnFileBox.sendKeys("12/16/2022");
			log.info("Enter Primary Sign on file");
			
			secondaryInsuranceExpandBtn.click();
			log.info("Expand the Secondary Insurance block");
			
			Select SecPlan = new Select(secondaryInsurancePlanDD);
			SecPlan.selectByIndex(2);
			log.info("Select the secondary Insurance Plan");
			
			Select SecAdd = new Select(secondaryInsuranceAddressDD);
			SecAdd.selectByIndex(1);
			log.info("Select the secondary Insurance Address");
			
			secondarySignOnFileBox.sendKeys("12/15/2022");
			log.info("Enter Secondary Sign on file");
			
			Thread.sleep(3000);
			
			Actions actions = new Actions(driver);
			actions.sendKeys(Keys.PAGE_UP).build().perform();
			actions.sendKeys(Keys.PAGE_UP).build().perform();
			actions.sendKeys(Keys.PAGE_UP).build().perform();
			
			saveBtn.click();
			log.info("Click on the save button");
			
			wait.until(ExpectedConditions.visibilityOf(duplicatePatientsFrame));
			
			driver.switchTo().frame(duplicatePatientsFrame);
			saveAsNewBtn.click();
									
			assertTrue(patientFullName.isDisplayed());
			log.info("Verify that Patient has been added");
						
		}
		
		public void CreateCase(){
			
			WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(30));
			
			driver.switchTo().defaultContent();
			log.info("Switch to default content");
			
			driver.switchTo().frame(patientMenuFrame);
			log.info("Switch to patient menu frame");
			
			wait.until(ExpectedConditions.visibilityOf(providerNotesBtn));
			providerNotesBtn.click();
			log.info("Click on the 'Provider Notes' button");
			
			log.info("Click on the 'New Case' button");
			newCaseBtn.click();
			
			driver.switchTo().defaultContent();
			log.info("Switch to default content");
			
			driver.switchTo().frame(mainFrame);
			log.info("Switch to main(body) frame");
			
			caseNameBox.sendKeys("Accident");
			log.info("Enter Case Name");
			
			caseOpenDateBox.sendKeys("12/16/2022");
			log.info("Enter Open Date");
			
			caseSaveBtn.click();
			log.info("Click Save Button");
			
			wait.until(ExpectedConditions.visibilityOf(deleteCaseBtn));
			assertTrue(deleteCaseBtn.isDisplayed());
			log.info("Verifuy that case has been created");
						
		}
		
		public void CreateProviderNote() {
			
			WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(30));
			
			driver.switchTo().defaultContent();
			log.info("Switch to default content");
			
			driver.switchTo().frame(patientMenuFrame);
			log.info("Switch to patient menu frame");
			
			wait.until(ExpectedConditions.visibilityOf(providerNotesBtn));
			providerNotesBtn.click();
			log.info("Click on the 'Provider Notes' button");
			
			log.info("Click on the 'New Provider Note' button");
			providerNotesBtn2.click();
			
			driver.switchTo().defaultContent();
			log.info("Switch to default content");
			
			driver.switchTo().frame(mainFrame);
			log.info("Switch to main(body) frame");
			
			addProviderNoteBtn.click();
			log.info("Click on the 'Add Provider Notes' button");
			
			providerNotesDateBox.sendKeys("12/16/2022");
			log.info("Enter date of 'Provider Notes'");
			
			providerBox.sendKeys("Aalumen, dasf");
			log.info("Enter name of the 'Provider'");
			
			Select Template = new Select(noteTemplateDD);
			Template.selectByIndex(2);
			log.info("Select Template of the note");
			
			Select Reason = new Select(visitReasonDD);
			Reason.selectByIndex(3);
			log.info("Select reason of the note");
			
			Select Type = new Select(noteTypeDD);
			Type.selectByIndex(4);
			log.info("Select Type of the note");
			
			createBtn.click();
			log.info("Click on create Button");
			
			assertTrue(patientFullName.isDisplayed());
			log.info("Verify that the note has been created");
						
		}
		
		
		   
		 
	

}
