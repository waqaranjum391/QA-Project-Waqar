package Project;

import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Project_Objects {
	
	WebDriver driver=new ChromeDriver();	
	Project_Methods Object = new Project_Methods(driver);
	
	@BeforeTest (description="Step 0 : Starting Chrome")
	public void openChrome() throws InterruptedException{

		driver.get("http://release01.curemd.com/curemdy/datlogin.asp");
		PropertyConfigurator.configure("log4j.properties");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		
		Object.LoginToThePortal();
	}
	
	@AfterTest
	public void quitChrome() throws InterruptedException {
		
		Thread.sleep(2000);
		driver.quit();
	}
	
	@Test(description="Add Patient")
	public void TestCase1() throws InterruptedException{
		
		Object.AddPatient();
		Object.CreateCase();
		Object.CreateProviderNote();
	}

}
